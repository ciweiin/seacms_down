<?php  
$lang['channellistInfo']['0']="<font color='red'> 对不起，无记录 </font>";
$lang['channellistInfo']['1']="指定分类错误";
$lang['searchlistInfo']['0']="对不起，没有找到任何记录,您可以<a target='_blank' href='gbook.php?key=";
$lang['searchlistInfo']['1']="'><font color='red'><b>在此留言</b></font></a>给我们。";
$lang['topicpageInfo']['0']="<font color='red'> 对不起，该专题无记录 </font>";
$lang['misc_cron_wesea_day_0']="日";
$lang['misc_cron_wesea_day_1']="一";
$lang['misc_cron_wesea_day_2']="二";
$lang['misc_cron_wesea_day_3']="三";
$lang['misc_cron_wesea_day_4']="四";
$lang['misc_cron_wesea_day_5']="五";
$lang['misc_cron_wesea_day_6']="六";
?>